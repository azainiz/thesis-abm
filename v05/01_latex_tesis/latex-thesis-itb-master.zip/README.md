# Format LaTeX Tesis Program Pascasarjana ITB

Halaman ini berisikan file LaTeX yang dapat digunakan sebagai template penulisan tugas akhir pada program pascasarjana ITB sesuai dengan pedoman penulisan Tesis Magister hasil revisi tahun 2016.
